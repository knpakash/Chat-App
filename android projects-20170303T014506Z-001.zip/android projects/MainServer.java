package chatting;

import java.io.*;
import java.net.*;
import org.json.simple.*;
import org.json.simple.parser.*;

public class MainServer {

               static ServerSocket mainSocket; 
               static volatile Socket[] sockArr = new Socket[100000]; 
               static volatile boolean[] isOnline = new boolean[100000];      

            public static void main(String args[]) throws Exception
              {

                        for(int i=0;i<100000;i++)
                          isOnline[i]=false;
                                        
                   mainSocket = new ServerSocket(7005);
                   System.out.println("listening on port 7005");
             
                      while(true)
                       {
                           Socket socket = mainSocket.accept();
                            System.out.println("connected to to the client");
                             MainThread thread = new MainThread(socket);
                               thread.start();
                        }

              }


              public static class MainThread extends Thread 
                 {
                       Socket socket;
                       int special_user_id;

                      MainThread(Socket s)
                       {
                             socket=s;
                       }

                    public void run()
                      {
                  try{
                          DataInputStream di = new DataInputStream(socket.getInputStream());
                          DataOutputStream dp = new DataOutputStream(socket.getOutputStream());
                         BufferedWriter bwr;
                         BufferedReader buf;
                         URL url;
                         HttpURLConnection con;
                         String str,s,username,password,name,city,mobile,sender_name,sender,receiver,msg_body,date,time,user_id;
                         String sender_username,search;
                         JSONParser parser;
                         JSONObject obj,o;
                           int id;
                          while(true)
                           {       
                                                         
                                    str=di.readUTF();                            
                                
                               parser = new JSONParser();
                               obj = (JSONObject)parser.parse(str);
                               int choice = Integer.parseInt((String)obj.get("choice"));
                               switch(choice)
                                {
                                   case 1:    username = (String)obj.get("username");
                                              password = (String)obj.get("password");
                                              name = (String)obj.get("name");
                                              city = (String)obj.get("city");
                                              mobile = (String)obj.get("mobile");

                                              url = new URL("http://localhost/chatphp/newuser.php");
                                              con = (HttpURLConnection)url.openConnection();
                                             con.setDoOutput(true);
                                             con.setRequestMethod("POST");

                                           bwr = new BufferedWriter(new OutputStreamWriter(con.getOutputStream(),"UTF-8"));

                                           str=URLEncoder.encode("username","UTF-8")+"="+URLEncoder.encode(username,"UTF-8")+"&"+
                                           URLEncoder.encode("password","UTF-8")+"="+URLEncoder.encode(password,"UTF-8")+"&"+
                                           URLEncoder.encode("city","UTF-8")+"="+URLEncoder.encode(city,"UTF-8")+"&"+
                                           URLEncoder.encode("name","UTF-8")+"="+URLEncoder.encode(name,"UTF-8")+"&"+
                                           URLEncoder.encode("mobile","UTF-8")+"="+URLEncoder.encode(mobile,"UTF-8");
                                           bwr.write(str);
                                           bwr.flush();
                                           bwr.close();

                                         buf = new BufferedReader(new InputStreamReader(con.getInputStream()));

                                          s="";
                                          while((str=buf.readLine())!=null)
                                            {
                                                s=s+str;
                                             }


                                           dp.writeUTF(s);
                                                                               
                                            return;

 
                                   case 2:   username = (String)obj.get("username");
                                             password = (String)obj.get("password");
                                             

                                             url = new URL("http://localhost/chatphp/login.php");
                                             con = (HttpURLConnection)url.openConnection();
                                             con.setDoOutput(true);    
                                             con.setRequestMethod("POST");


                                        bwr = new BufferedWriter(new OutputStreamWriter(con.getOutputStream(),"UTF-8"));
                      
                                        str=URLEncoder.encode("username","UTF-8")+"="+URLEncoder.encode(username,"UTF-8")+"&"+
                                         URLEncoder.encode("password","UTF-8")+"="+URLEncoder.encode(password,"UTF-8");
                         
                                        bwr.write(str);
                                        bwr.flush();
                                        bwr.close();

                                       buf = new BufferedReader(new InputStreamReader(con.getInputStream()));

                                       s="";
                                       while((str=buf.readLine())!=null)
                                         s+=str;
                     
                                         dp.writeUTF(s);

                                            return;



            case 3:    receiver = (String)obj.get("receiver");
                       url = new URL("http://localhost/chatphp/retrieve_messages.php");
                       
                       con = (HttpURLConnection)url.openConnection();
                       con.setDoOutput(true);    
                       con.setRequestMethod("POST");

                          
                        bwr = new BufferedWriter(new OutputStreamWriter(con.getOutputStream(),"UTF-8"));
                      
                        str=URLEncoder.encode("receiver","UTF-8")+"="+URLEncoder.encode(receiver,"UTF-8");
                         
                         bwr.write(str);
                         bwr.flush();
                         bwr.close();

                      buf = new BufferedReader(new InputStreamReader(con.getInputStream()));
                        
                          s="";
                        while((str=buf.readLine())!=null)
                          s+=str;

                           dp.writeUTF(s);

                        isOnline[Integer.parseInt(receiver)]=true;
                        sockArr[Integer.parseInt(receiver)]=socket;
                        special_user_id=Integer.parseInt(receiver);

                         url = new URL("http://localhost/chatphp/delete_messages.php");
                        con = (HttpURLConnection)url.openConnection();
                       con.setDoOutput(true);    
                       con.setRequestMethod("POST");


                       bwr = new BufferedWriter(new OutputStreamWriter(con.getOutputStream(),"UTF-8"));
                     
                        str=URLEncoder.encode("receiver","UTF-8")+"="+URLEncoder.encode(receiver,"UTF-8");

                         bwr.write(str);
                         bwr.flush();
                         bwr.close(); 
                           
                         buf = new BufferedReader(new InputStreamReader(con.getInputStream()));

                           s="";
                        while((str=buf.readLine())!=null)
                          s+=str;

 //                          System.out.println(s);

                                 
                           socket.setSoTimeout(10000);
                         
                         break;


            case 4:     sender = (String)obj.get("sender");
                        sender_name = (String)obj.get("sender_name");
                        sender_username=(String)obj.get("sender_username");
                        receiver = (String)obj.get("receiver");
                        msg_body = (String)obj.get("msg_body");
                        date = (String)obj.get("date");
                        time = (String)obj.get("time");

                          int r = Integer.parseInt(receiver);


                         if(isOnline[r])
                          {
 //                               System.out.println("online hai");
                                 o = new JSONObject();
                                o.put("sender",sender);
                                o.put("sender_name",sender_name);
                                o.put("sender_username",sender_username);
                                o.put("receiver",receiver);
                                o.put("msg_body",msg_body);
                                o.put("date",date);
                                o.put("time",time);
                                DataOutputStream out = new DataOutputStream((sockArr[r]).getOutputStream());
                                out.writeUTF(o.toString());
                          }
                        else
                          {
 //                               System.out.println("online nahi hai");
                                url = new URL("http://localhost/chatphp/insert_message.php");
                                con = (HttpURLConnection)url.openConnection();
                               con.setDoOutput(true);    
                               con.setRequestMethod("POST");


                            bwr = new BufferedWriter(new OutputStreamWriter(con.getOutputStream(),"UTF-8"));
                   
                            str=URLEncoder.encode("sender","UTF-8")+"="+URLEncoder.encode(sender,"UTF-8")+"&"+
                            URLEncoder.encode("receiver","UTF-8")+"="+URLEncoder.encode(receiver,"UTF-8")+"&"+
                            URLEncoder.encode("msg_body","UTF-8")+"="+URLEncoder.encode(msg_body,"UTF-8")+"&"+
                            URLEncoder.encode("date","UTF-8")+"="+URLEncoder.encode(date,"UTF-8")+"&"+
                            URLEncoder.encode("time","UTF-8")+"="+URLEncoder.encode(time,"UTF-8")+"&"+
                            URLEncoder.encode("sender_name","UTF-8")+"="+URLEncoder.encode(sender_name,"UTF-8")+"&"+
                            URLEncoder.encode("sender_username","UTF-8")+"="+URLEncoder.encode(sender_username,"UTF-8");
                         
                            bwr.write(str);
                            bwr.flush();
                            bwr.close();

                            buf = new BufferedReader(new InputStreamReader(con.getInputStream()));
                              s="";
                              while((str=buf.readLine())!=null)
                                s=s+str;
 //                              System.out.println(s);
                         }
                              break;


                 case 5:    JSONArray arr = (JSONArray)obj.get("contacts");
                            JSONArray arr2=new JSONArray();
 //                               System.out.print(arr.size()+"   ");
                             for(int i=0;i<arr.size();i++)
                               {
                                   id = Integer.parseInt((String)arr.get(i));
                                     if(isOnline[id])
                                       arr.set(i,"1");
                                     else
                                       arr.set(i,"0");
                               }
 //                                  System.out.println(arr.size());
                             dp.writeUTF(arr.toString());
 //                                    socket.setSoTimeout(10000);
  //                                 System.out.println("jjnjn");
                                  break;
 
                case 6:     search = (String)obj.get("search");
                             url = new URL("http://localhost/chatphp/search.php");
                            con = (HttpURLConnection)url.openConnection();
                            con.setDoOutput(true);    
                            con.setRequestMethod("POST");


                           bwr = new BufferedWriter(new OutputStreamWriter(con.getOutputStream(),"UTF-8"));
                      
                        str=URLEncoder.encode("search","UTF-8")+"="+URLEncoder.encode(search,"UTF-8");
                         
                         bwr.write(str);
                         bwr.flush();
                         bwr.close();

                         buf = new BufferedReader(new InputStreamReader(con.getInputStream()));
                        
                          s="";
                        while((str=buf.readLine())!=null)
                          s+=str;  

 //                         System.out.println(s);
                        
                           dp.writeUTF(s);
 
                               return;


                 case 7:       user_id = (String)obj.get("user_id");
                                url= new URL("http://localhost/chatphp/view_profile.php");
                               con = (HttpURLConnection)url.openConnection();
                               con.setDoOutput(true);    
                               con.setRequestMethod("POST");               

                              bwr = new BufferedWriter(new OutputStreamWriter(con.getOutputStream(),"UTF-8"));

                              str=URLEncoder.encode("user_id","UTF-8")+"="+URLEncoder.encode(user_id,"UTF-8");

                              bwr.write(str);
                              bwr.flush();
                              bwr.close();

                             buf = new BufferedReader(new InputStreamReader(con.getInputStream()));
                        
                              s="";
                              while((str=buf.readLine())!=null)
                                s+=str;  

  //                            System.out.println(s);
                        
                              dp.writeUTF(s);
                             
                               return;

                    case 8:       id = Integer.parseInt((String)obj.get("user_id"));
                                   isOnline[id]=false;
                                    sockArr[id].close();
                                   return;

                   case 9:     //   System.out.println("okok");   
                                   break;

                     }
                  }
                }
                catch(SocketTimeoutException e){
  //                           System.out.println("connection closed");
 //                            System.out.println("special_user_id =  "+special_user_id);
                              isOnline[special_user_id]=false;
                            e.printStackTrace();
                     }
                  
                catch(Exception e){
                              e.printStackTrace();
                      }
             }
       }

}



                                       
                                        
                                            















