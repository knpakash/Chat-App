-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 03, 2016 at 09:21 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.5.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chatapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `msg_id` int(11) NOT NULL,
  `sender` int(11) NOT NULL,
  `receiver` int(11) NOT NULL,
  `msg_body` text,
  `date` varchar(40) DEFAULT NULL,
  `time` varchar(40) DEFAULT NULL,
  `sender_name` varchar(30) NOT NULL,
  `sender_username` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`msg_id`, `sender`, `receiver`, `msg_body`, `date`, `time`, `sender_name`, `sender_username`) VALUES
(17, 20, 29, 'hello', '28/05/2016', '23:27', 'def', 'def'),
(18, 20, 29, 'how are you', '28/05/2016', '23:27', 'def', 'def'),
(19, 20, 29, 'sahi chal raha hai', '28/05/2016', '23:27', 'def', 'def'),
(20, 20, 29, 'ok bye', '28/05/2016', '23:28', 'def', 'def'),
(21, 20, 29, 'hello bhai again', '28/05/2016', '23:29', 'def', 'def'),
(22, 20, 29, 'hello mr ', '28/05/2016', '23:36', 'def', 'def'),
(23, 20, 29, 'bye bye', '28/05/2016', '23:38', 'def', 'def'),
(24, 20, 29, 'akhir  ban hi code ', '29/05/2016', '00:48', 'def', 'def'),
(25, 20, 29, 'to kya hal chal', '29/05/2016', '00:52', 'def', 'def'),
(26, 20, 29, 'sahi ho', '29/05/2016', '00:52', 'def', 'def'),
(27, 20, 29, 'dekhte hai', '29/05/2016', '14:13', 'def', 'def'),
(28, 20, 22, 'samjho ho hi gaya', '30/05/2016', '01:49', 'def', 'def'),
(29, 20, 29, 'aja aja aja aja a a', '30/05/2016', '01:51', 'def', 'def');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `city` varchar(20) DEFAULT NULL,
  `name` varchar(30) NOT NULL,
  `mobile` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `password`, `city`, `name`, `mobile`) VALUES
(18, 'bxbxn', 'gzjnxnxj', 'bxhxju', 'hshhxxj', '546767'),
(19, 'hdjxnhx', 'hdhxjjx', 'hdhbdbx', 'hbdgdhsjhd', '5466449646'),
(20, 'def', 'def', 'kanpur', 'def', '8745325730'),
(21, 'kaifp', 'jcnek', 'jdjjxkx', 'jsldncm', '64681946'),
(22, 'hdbxnx', 'hhdxnxn', 'bcncncj', 'hdxnxn', '6868645'),
(23, 'gshxhxh', 'hhdxnxn', 'bcncncj', 'hdxnxn', '6868645'),
(24, 'hdjdjdj', 'hxjjdxn', 'bfndmc', 'ndnnxnxn', '5487643'),
(25, 'hdnxn', 'hdhxnjx', 'bxnxnnx', 'bdnxjnx', '548467'),
(26, 'hsbxnjd', 'hdjdjxj', 'bdnxnxj', 'hdjjxkjx', '67998986'),
(27, 'hzhxjj', 'hdhxjjx', 'nxnxjck', 'nndnxnx', '5466767'),
(28, 'nsnsnx', 'hdnnxnnx', 'bcnncncn', 'ncnncnnc', '548898'),
(29, 'cdn', 'cdbhcd', 'aada', 'alakaj', '1234567899'),
(30, 'jsjxb', 'hcbbxb', 'bdbdndn', 'bdbxjjx', '64885968'),
(31, 'knpakash', 'knpakash', 'kanpur', 'akash agrawal', '8765583713'),
(32, 'al', 'al', 'al', 'al', '8466');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`msg_id`),
  ADD KEY `sender` (`sender`),
  ADD KEY `receiver` (`receiver`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `msg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`sender`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`receiver`) REFERENCES `user` (`user_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
